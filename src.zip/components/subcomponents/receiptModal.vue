<template>
  <!-- <modal name="receiptModal" @before-open="beforeOpen" :width="300" :height="300">
    <button >
      닫기
    </button>
  </modal> -->
</template>

<script>
import Vue from 'vue'

export default {
  name: 'receiptModal',
  props: [],
  data () {
    return {
    }
  },
  methods: {

  }
}
</script>
